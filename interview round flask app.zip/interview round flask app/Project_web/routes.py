from flask import render_template, url_for, flash, redirect, request
from Project_web import app, db, bcrypt
from Project_web.forms import RegistrationForm, LoginForm
from Project_web.models import Users,Task_book,Book_entries
from flask_login import login_user, current_user, logout_user, login_required

@app.route("/")
def home():
    return render_template('home.html')

@app.route("/about")
def about():
    return render_template('about.html', title='About')

@app.route("/register", methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = RegistrationForm(request.form) 
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = Users(fname=form.fname.data, lname=form.lname.data, email=form.email.data, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash('Your account has been created! You are now able to log in', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

@app.route("/login", methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = LoginForm()
    if form.validate_on_submit():
        user = Users.query.filter_by(email=form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user, remember=form.remember.data)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('home'))
        else:
            flash('Login Unsuccessful. Please check email and password', 'danger')
    return render_template('login.html', title='Login', form=form)

@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route("/books")
def books():
    books = Task_book.query.all()
    return render_template('books.html', books=books)

@app.route("/addbook", methods=['GET', 'POST'])
def addbook():
    user_id=current_user.get_id()
    if request.method=='POST':
        title = request.form['title']
        content_type = request.form['content_type']
        book = Task_book(title=title, content_type=content_type, user_id=user_id)
        db.session.add(book)
        db.session.commit()
        flash('Your Book has been created! You are now able to update in the book', 'success')
        return redirect(url_for('books'))
    return render_template('addbook.html')

@app.route('/delete/<int:id>')
def delete(id):
    todo = Task_book.query.filter_by(id=id).first()
    db.session.delete(todo)
    db.session.commit()
    return redirect(url_for('books'))

@app.route('/editbook/<int:id>', methods=['GET', 'POST'])
def editbook(id):
    book = Task_book.query.filter_by(id=id).first()
    if request.method=='POST':
        content = request.form['content']
        task = Book_entries(content=content, user_id=id)
        db.session.add(task)
        db.session.commit()
        return redirect(url_for('books'))
    tasks = Book_entries.query.filter_by(user_id=id).all()
    return render_template('editbook.html', book=book, tasks=tasks)